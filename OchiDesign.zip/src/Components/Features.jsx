import { motion, useAnimation } from "framer-motion";
import React from "react";

function Features() {
  const cards = [useAnimation(), useAnimation()];

  const handleHover = (index) => {
    cards[index].start({ y: "0" });
  };

  const handleHoverEnd = (index) => {
    cards[index].start({ y: "100%" });
  };

  return (
    <div className=" w-full py-20 font-neue bg-[#F1F1F1] ">
      <div className="w-full px-24 border-b-[1px] pb-20 border-zinc-500">
        <h1 className="text-7xl tracking-tight pb-10">Featured projects</h1>
      </div>
      <div className="wholecard">
        <div className="cards w-full flex gap-9 rounded-2xl mt-24 px-20">
          <motion.div
            onHoverStart={() => handleHover(0)}
            onHoverEnd={() => handleHoverEnd(0)}
            className="cardcontainer relative w-1/2 h-[70vh] "
          >
            <h1 className=" absolute flex overflow-hidden left-full -translate-x-1/2 top-1/2 -translate-y-1/2 z-[9] uppercase text-[#CDEA68] text-8xl leading-none font-black tracking-tight whitespace-nowrap">
              {"Salience Labs".split("").map((item, index) => (
                <motion.span
                  initial={{ y: "100%" }}
                  animate={cards[0]}
                  transition={{ ease: [0.22, 1, 0.36, 1], delay: index * 0.05 }}
                  className="inline-block"
                >
                  {item}
                </motion.span>
              ))}
            </h1>
            <div className=" card w-full h-full rounded-xl">
              <img
                className="w-full h-full bg-cover rounded-xl"
                src="/images/Image1.png"
                alt=""
              />
            </div>
          </motion.div>
          <motion.div
            onHoverStart={() => handleHover(1)}
            onHoverEnd={() => handleHoverEnd(1)}
            className="cardcontainer relative w-1/2 h-[70vh]"
          >
            <h1 className=" absolute flex overflow-hidden right-full translate-x-1/2 top-1/2 -translate-y-1/2 z-[9] uppercase text-[#CDEA68] text-8xl leading-none font-black tracking-tight whitespace-nowrap">
              {"Cardboard Spaceship".split("").map((item, index) => (
                <motion.span
                  initial={{ y: "100%" }}
                  animate={cards[1]}
                  transition={{ ease: [0.22, 1, 0.36, 1], delay: index * 0.05 }}
                  className="inline-block"
                >
                  {item}
                </motion.span>
              ))}
            </h1>
            <div className=" card w-full h-full rounded-xl overflow-hidden">
              <img
                className="w-full h-full bg-cover rounded-xl"
                src="/images/Image2.png"
                alt=""
              />
            </div>
          </motion.div>
        </div>
      </div>
      <div className="wholecard">
        <div className="cards w-full flex gap-9 rounded-2xl mt-24 px-20">
          <motion.div
            onHoverStart={() => handleHover(0)}
            onHoverEnd={() => handleHoverEnd(0)}
            className="cardcontainer relative w-1/2 h-[70vh] "
          >
            <h1 className=" absolute flex overflow-hidden left-full -translate-x-1/2 top-1/2 -translate-y-1/2 z-[9] uppercase text-[#CDEA68] text-8xl leading-none font-black tracking-tight whitespace-nowrap">
              {"Fyde".split("").map((item, index) => (
                <motion.span
                  initial={{ y: "100%" }}
                  animate={cards[0]}
                  transition={{ ease: [0.22, 1, 0.36, 1], delay: index * 0.05 }}
                  className="inline-block"
                >
                  {item}
                </motion.span>
              ))}
            </h1>
            <div className=" card w-full h-full rounded-xl">
              <img
                className="w-full h-full bg-cover rounded-xl"
                src="/images/Fyde.png"
                alt=""
              />
            </div>
          </motion.div>
          <motion.div
             onHoverStart={() => handleHover(1)}
            onHoverEnd={() => handleHoverEnd(1)}
           className="cardcontainer relative w-1/2 h-[70vh]">
            <h1 className=" absolute flex overflow-hidden right-full translate-x-1/2 top-1/2 -translate-y-1/2 z-[9] uppercase text-[#CDEA68] text-8xl leading-none font-black tracking-tight whitespace-nowrap">
              {"Vise".split("").map((item, index) => (
                <motion.span
                  initial={{ y: "100%" }}
                  animate={cards[1]}
                  transition={{ ease: [0.22, 1, 0.36, 1], delay: index * 0.05 }}
                  className="inline-block"
                >
                  {item}
                </motion.span>
              ))}
            </h1>
            <div className=" card w-full h-full rounded-xl overflow-hidden">
              <img
                className="w-full h-full bg-cover rounded-xl"
                src="/images/Vise.png"
                alt=""
              />
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default Features;
