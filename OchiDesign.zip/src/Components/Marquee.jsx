import React from "react";

function Marquee() {
  return (
    <div className="w-full py-20 rounded-tl-3xl rounded-tr-3xl bg-[#004D43] font-founders overflow-hidden relative">
      <div className="border-t-2 border-b-2 border-zinc-400 whitespace-nowrap flex">
        <div className="marquee-content">
          <span className="marquee-text">we are ochi  we are ochi  we are ochi  we are ochi  </span>
        </div>
      </div>

      <style>
        {`
          .marquee-content {
            display: inline-block;
            white-space: nowrap;
            animation: marquee 25s linear infinite;
          }
          .marquee-text {
            font-size: 350px;
            color: #FFFFFF;
            font-weight: 700;
            text-transform: uppercase;
            line-height: 1;
          }
          @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-100%); }
          }
        `}
      </style>
    </div>
  );
}

export default Marquee;
