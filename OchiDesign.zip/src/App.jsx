import { useEffect, useRef } from "react";
import LocomotiveScroll from "locomotive-scroll";
import "locomotive-scroll/dist/locomotive-scroll.css";

import NavBar from "./Components/NavBar";
import LandingPage from "./Components/LandingPage";
import Marquee from "./Components/Marquee";
import About from "./Components/About";
import AnimateEye from "./Components/AnimateEye";
import Features from "./Components/Features";
import Footer from "./Components/Footer";

function App() {
  // ✅ Create references
  const scrollRef = useRef(null);
  const locoScrollInstance = useRef(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      // ✅ Initialize LocomotiveScroll
      locoScrollInstance.current = new LocomotiveScroll({
        el: scrollRef.current,
        smooth: true,
        multiplier: 1,
        smartphone: {
          smooth: true,
        },
        tablet: {
          smooth: true,
        },
      });
    }

    // ✅ Return cleanup function here 👇👇👇
    return () => {
      if (locoScrollInstance.current) {
        locoScrollInstance.current.destroy();
      }
    };
  }, []); // Empty dependency array → runs only once after mount

  return (
    <div data-scroll-container ref={scrollRef}>
      <NavBar />
      <LandingPage />
      <Marquee />
      <About />
      <AnimateEye />
      <Features />
      <Footer />
    </div>
  );
}

export default App;
